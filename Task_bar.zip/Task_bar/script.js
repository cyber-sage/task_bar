
//variables

const addServer= document.getElementById("add-server-button");
const leftdiv=document.getElementById("left-div");
const serverdiv=document.querySelector(".server-div");
const removeServer=document.getElementById("remove-server");
const addTask=document.getElementById("add-task-button");
const middleDiv=document.getElementById("center-div");




 


//funstions and event listeners

//add server
addServer.addEventListener('click',()=>{

   var clone=serverdiv.cloneNode(true);
   leftdiv.appendChild(clone);
   console.log(taskInput);


});
//remove server event
removeServer.addEventListener("click",()=>{

  leftdiv.removeChild(leftdiv.lastChild);

});
//function for add task
 const lifeSaver= async ()=>{
   
    var taskInput=document.getElementById("task-input").value;
    const serverdivs=document.querySelectorAll('.server-div');
     let len=serverdivs.length;
     if(len==0)alert("please Add server and then add tasks");
     else {

        let multi=(taskInput/len) | 0;
     let mod=taskInput%len;
     console.log(multi);
     let left=taskInput-len;
     for(let i=0;i<left;i++){
        
        let waitingDiv=document.createElement('div');
        waitingDiv.innerHTML="waiting-List";
        waitingDiv.classList.add('wait-div');
         middleDiv.append(waitingDiv);
         console.log(i);
     }
     //loop to add task
     while (multi-->0){
         await new Promise(resolve=>setTimeout(resolve,1000));
         console.log("huihui");
    for await(const server of serverdivs){
        
        // console.log("k"+i);
        await new Promise(resolve=>setTimeout(resolve,1000));
        server.querySelector('.pp').style.display = "block";
        server.querySelector('.progress-bar').animate(
            {
              width: '100%'
            }, 
            {
              duration: 3000      
            }        
          );
        
          setTimeout(()=>{
     
            middleDiv.removeChild(middleDiv.lastChild);
            // server.querySelector('.pp').style.display="none";
             $('.progress-bar').css("width","0px");
            
     
          },3000) ;

          

    }
}
//loop to add remaining task
for(let i=0;i<mod;i++){
    
    await new Promise(resolve=>setTimeout(resolve,1000));
    serverdivs[i].querySelector('.pp').style.display="block";
    console.log("huihui");
    serverdivs[i].querySelector('.progress-bar').animate(
        {
          width: '100%'
        }, 
        {
          duration: 3000      
        }        
      );
    
       setTimeout(()=>{
 
        
        
         $('.progress-bar').css("width","0px");
        
 
      },3000) ;

    

      

}

     }
     

}
//add Task event
addTask.addEventListener('click',()=>{
    
    lifeSaver();
    
    
});


